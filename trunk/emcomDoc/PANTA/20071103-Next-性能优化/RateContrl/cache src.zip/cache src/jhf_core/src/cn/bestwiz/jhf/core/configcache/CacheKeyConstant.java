package cn.bestwiz.jhf.core.configcache;

import cn.bestwiz.jhf.core.dao.bean.main.JhfApplicationDate;
import cn.bestwiz.jhf.core.dao.bean.main.JhfCurrency;
import cn.bestwiz.jhf.core.dao.bean.main.JhfLevel;
import cn.bestwiz.jhf.core.tools.SimpleTreeCache;

public interface CacheKeyConstant {
	
	public final static String CACHE_KEY_ALL = "ALL"+SimpleTreeCache.TOKEN ;
	
	public final static String CACHE_KEY_CURRENCUY_ALL = CACHE_KEY_ALL+JhfCurrency.class.getName() + SimpleTreeCache.TOKEN + "ALL";

	public final static String CACHE_KEY_LEVEL_ALL = CACHE_KEY_ALL+JhfLevel.class.toString() + SimpleTreeCache.TOKEN + "ALL";

	public final static String CACHE_KEY_APPLICATION_DATE_BY_KEY = CACHE_KEY_ALL+JhfApplicationDate.class.toString() + SimpleTreeCache.TOKEN + "BY_KEY";
	
	
	
	
}
