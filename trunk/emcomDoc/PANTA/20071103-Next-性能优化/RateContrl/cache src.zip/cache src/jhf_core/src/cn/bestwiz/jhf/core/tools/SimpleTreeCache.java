package cn.bestwiz.jhf.core.tools;


import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

/**
 *a simple cascade cache used for cache object .
 *
 *<pre>
 *	this is a simpe tree cache . and path is depart by "|",
 *if put a object  with path "|a|b" , that mean a inner struture 
 *like following :
 * ->HashMap - key is a 
 *     ->HashMap --key is b 
 *         ->object --- value the need put object .
 * 
 * 
 *  notice, this cache only support same level path .
 * that mean , if you  put a object with path "|a", 
 * than you can not put a object with path  "|a|b";
 *</pre>
 **@author zhouhc
 */
public class SimpleTreeCache {

	private Map root = Collections.synchronizedMap(new HashMap());
	

	public static final String TOKEN = "\t";
	
	
	private static SimpleTreeCache simpleTreeCache= null;
	
	private SimpleTreeCache(){}
	
	public static  SimpleTreeCache getInstance(){
		if(simpleTreeCache==null){
			simpleTreeCache = new SimpleTreeCache();
		}
		return simpleTreeCache;
	}
	 
	public synchronized void put( String path , Object value  ) {
		this.putToMap(path, value, root, TOKEN);
	}
	
	public synchronized Object get( String path ) {
		if( path == null ) return root ;
		
		
		String[] keys = strToken(path, TOKEN);
		Map  currentNode = root ;
		if( keys.length == 0 ){
			return currentNode ;
		}
		Object  value = null ;
		for( int i=0 ; i< keys.length; i++ ){
			String key = keys[i];
			value = currentNode.get( key );
			if( null == value ){
				break ;
			}else if( value instanceof Map){
				currentNode = ( Map ) value ;
			}else if( i != keys.length -1 ) {
				value = null ;
				break ;
			}
		}
		return value ;
	}
	
	
	public synchronized void clear( String path ){
		clearFromMap(path, root, TOKEN);
	}
	
	
	
	

	private void putToMap( String path, 
			Object value, 
			Map destMap, 
			String token ){
		if( path == null )return  ;	
		
		String[] keys = strToken(path, token);
		Map  currentNode = destMap ;
		for( int i=0 ; i< keys.length; i++ ){
			String key = keys[i];
			Object  obj = currentNode.get( key );
			
			if( i == keys.length-1 ){
				currentNode.put( key, value );
			}
			else {
				if( null == obj ){
					Map newNode = new HashMap();
					currentNode.put(key, newNode );
					currentNode = newNode ;
				}else{
					currentNode = ( Map )obj ;
				}	
			}
		}
	}
	

	private  void clearFromMap( 
			String path,
			Map  srcMap,
			String token){
		if( path == null 
				|| path.length() == 0 
				|| path.equals(TOKEN) ){
			srcMap.clear();
			return ;
		}	
		
		String[] keys = strToken(path, token);
		Map  currentNode = srcMap ;
		if( keys.length == 0 ){
			srcMap.clear();
		}
		
		for( int i=0 ; i< keys.length; i++ ){
			String key = keys[i];
			Object value = currentNode.get( key );
			if( !(value instanceof Map) ){
				currentNode.remove( key );
			}else {
				currentNode = ( Map ) value ;
				if ( i == keys.length -1  ){
					currentNode.clear();
				}	
			}
		}
	}
	

	private String[] strToken( String src , String seprator ){
		StringTokenizer  toker = new StringTokenizer(src, TOKEN, false); 
		String[] splitedStrs = new String[toker.countTokens()];
		for ( int i=0 ; i<splitedStrs.length; i++ ) {
			splitedStrs[i] = toker.nextToken();
		}
		return splitedStrs ;
	}
	
	
	
}
