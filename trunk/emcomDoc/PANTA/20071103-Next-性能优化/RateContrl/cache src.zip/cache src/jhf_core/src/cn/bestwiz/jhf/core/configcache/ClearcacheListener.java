package cn.bestwiz.jhf.core.configcache;

import java.io.Serializable;
import java.net.InetAddress;
import java.util.List;

import org.apache.commons.logging.Log;

import cn.bestwiz.jhf.core.dao.bean.info.JhfClearCacheManage;
import cn.bestwiz.jhf.core.dao.util.DbSessionFactory;
import cn.bestwiz.jhf.core.idgenerate.IdGenerateFacade;
import cn.bestwiz.jhf.core.jms.DestinationConstant;
import cn.bestwiz.jhf.core.jms.SimpleCallback;
import cn.bestwiz.jhf.core.jms.SimpleReceiver;
import cn.bestwiz.jhf.core.tools.SimpleTreeCache;
import cn.bestwiz.jhf.core.util.DateHelper;
import cn.bestwiz.jhf.core.util.LogUtil;
import cn.bestwiz.jhf.core.util.SystemConstants;

public class ClearcacheListener extends Thread{
	
	private final static Log m_log = LogUtil.getLog(ClearcacheListener.class);

	private SimpleReceiver receiver = null;

	
	ClearcacheListener(){}
	
	
	public void run() {
		try {
			
			receiver = new SimpleReceiver(DestinationConstant.ClearDaoCacheTopic, true);
			System.out.println(receiver.getDestString());
			receiver.addCallback(new SimpleCallback() {
				public void onMessage(Serializable message) {
					SimpleTreeCache cache = SimpleTreeCache.getInstance();
					cache.clear(message.toString());
					m_log.info("ClearcacheListener Recieved!!!");
					// insertDBmsg(realClearedClass);
				}
			}
			);

		} catch (Exception e) {
			m_log.error(" ClearCacheRunner Exception!!! ", e);
			e.printStackTrace();
		}
	}
	
	
	
	private void insertDBmsg(List<Class> realClearedClass){
		String notice = null;
		if(realClearedClass.size()==1){
			notice = "clear  cache for " + realClearedClass.get(0).getName();
		}else{
			notice = "clear all  cache!!!";
		}
		
		try {
			DbSessionFactory.beginTransaction(DbSessionFactory.INFO);
			JhfClearCacheManage manage = new JhfClearCacheManage();
			manage.setProcessId(IdGenerateFacade.getClearDaoManageId());
			manage.setInsertTime(DateHelper.getTodaysTimestamp());
			manage.setIpAddess(InetAddress.getLocalHost().getHostAddress());
			manage.setProcessName(System.getProperty(SystemConstants.PROCESS_NAME));
			manage.setNotice(notice);
			DbSessionFactory.infoSession().save(manage);
			DbSessionFactory.commitTransaction(DbSessionFactory.INFO);
		} catch (Exception e) {
			DbSessionFactory.rollbackTransaction(DbSessionFactory.INFO);
			m_log.error("insertDBmsg Failed!!", e);
			e.printStackTrace();
		}
	}
	
	
	
	
}
