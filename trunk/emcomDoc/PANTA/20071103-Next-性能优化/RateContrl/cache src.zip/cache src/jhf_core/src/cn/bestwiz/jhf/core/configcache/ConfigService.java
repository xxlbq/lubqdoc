package cn.bestwiz.jhf.core.configcache;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.logging.Log;
import org.hibernate.LockMode;

import cn.bestwiz.jhf.core.dao.ConfigDao;
import cn.bestwiz.jhf.core.dao.bean.main.JhfApplicationDate;
import cn.bestwiz.jhf.core.dao.bean.main.JhfCurrency;
import cn.bestwiz.jhf.core.dao.bean.main.JhfLevel;
import cn.bestwiz.jhf.core.dao.util.DbSessionFactory;
import cn.bestwiz.jhf.core.util.LogUtil;

class ConfigService {

	private Log m_log = LogUtil.getLog(ConfigService.class);

	
	public Object get(Class clazz, Serializable id, LockMode lockMode ,int dbSession) throws Exception {
		Object obj = null;
		try {
			DbSessionFactory.beginTransaction(dbSession);
			ConfigDao dao = new ConfigDao();
			obj = dao.get(clazz, id, lockMode);	
			DbSessionFactory.commitTransaction(dbSession);
		} catch (Exception e) {
			DbSessionFactory.rollbackTransaction(dbSession);
			throw e;
		}
		
		return obj;
	}
	
	
	
	@SuppressWarnings("unchecked")
	public List<JhfCurrency> getAllJhfCurrency() throws Exception {
		List<JhfCurrency> lstJhfCurrency = null;

		try {
			DbSessionFactory.beginTransaction(DbSessionFactory.MAIN);

			ConfigDao dao = new ConfigDao();
			lstJhfCurrency = dao.getAllJhfCurrency();

			DbSessionFactory.commitTransaction(DbSessionFactory.MAIN);
		} catch (Exception e) {
			DbSessionFactory.rollbackTransaction(DbSessionFactory.MAIN);
			m_log.error("getAllJhfCurrency failed", e);
			throw e;
		}

		return lstJhfCurrency;

	}
	
	

	@SuppressWarnings("unchecked")
	public List<JhfLevel> getAllLevel() throws Exception {
		List<JhfLevel> lstJhfLevel = null;

		try {
			DbSessionFactory.beginTransaction(DbSessionFactory.MAIN);

			ConfigDao dao = new ConfigDao();
			lstJhfLevel = dao.getAllLevel();

			DbSessionFactory.commitTransaction(DbSessionFactory.MAIN);
		} catch (Exception e) {
			DbSessionFactory.rollbackTransaction(DbSessionFactory.MAIN);
			m_log.error("getAllLevel failed", e);
			throw e;
		}

		return lstJhfLevel;

	}
	

	public JhfApplicationDate getApplicationDate(String dateKey) throws Exception {
		JhfApplicationDate date = null;
		try {

			DbSessionFactory.beginTransaction(DbSessionFactory.MAIN);

			ConfigDao dao = new ConfigDao();
			date = dao.getApplicationDate(dateKey);

			DbSessionFactory.commitTransaction(DbSessionFactory.MAIN);
		} catch (Exception e) {
			m_log.error("getApplicationDate failed", e);
			throw new Exception(e);
		}
		return date;
	}

}
