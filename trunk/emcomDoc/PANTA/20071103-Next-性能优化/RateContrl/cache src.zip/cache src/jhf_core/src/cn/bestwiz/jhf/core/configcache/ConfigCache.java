package cn.bestwiz.jhf.core.configcache;

import java.io.Serializable;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.hibernate.LockMode;

import cn.bestwiz.jhf.core.bo.enums.BoolEnum;
import cn.bestwiz.jhf.core.dao.bean.main.JhfApplicationDate;
import cn.bestwiz.jhf.core.dao.bean.main.JhfCounterparty;
import cn.bestwiz.jhf.core.dao.bean.main.JhfCounterpartyCurrencypair;
import cn.bestwiz.jhf.core.dao.bean.main.JhfCurrency;
import cn.bestwiz.jhf.core.dao.bean.main.JhfCurrencyHoliday;
import cn.bestwiz.jhf.core.dao.bean.main.JhfCurrencyHolidayMaster;
import cn.bestwiz.jhf.core.dao.bean.main.JhfCurrencyPair;
import cn.bestwiz.jhf.core.dao.bean.main.JhfHoliday;
import cn.bestwiz.jhf.core.dao.bean.main.JhfLevel;
import cn.bestwiz.jhf.core.dao.bean.main.JhfLeverageGroup;
import cn.bestwiz.jhf.core.dao.bean.main.JhfProduct;
import cn.bestwiz.jhf.core.dao.bean.main.JhfSpread;
import cn.bestwiz.jhf.core.dao.bean.main.JhfStatusContrl;
import cn.bestwiz.jhf.core.dao.bean.main.JhfTradeConstraint;
import cn.bestwiz.jhf.core.dao.util.DbSessionFactory;
import cn.bestwiz.jhf.core.tools.SimpleTreeCache;
import cn.bestwiz.jhf.core.util.LogUtil;
/**
 * 
 * JHF_APPLICATION_DATE
 * JHF_APP_PROPERTY
 * JHF_TRADE_CONSTRAINT
 * JHF_CURRENCY
 * JHF_CURRENCY_PAIR
 * JHF_PRODUCT
 * JHF_COUNTERPARTY
 * JHF_COUNTERPARTY_CURRENCYPAIR
 * JHF_MAIL_ACTION
 * JHF_SYS_MAIL_ACTION
 * JHF_SPOT_RATE_CONFIG

 * JHF_SPREAD
 * JHF_HOLIDAY
 * JHF_GROUP
 * JHF_GROUP_PRODUCT_BAND
 * JHF_STATUS_CONTRL
 * JHF_DL_PROPERTY
 * JHF_HEDGER_MODE
 * JHF_CURRENCY_HOLIDAY
 * JHF_CURRENCY_HOLIDAY_MASTER
 * JHF_SWAP_POINT
 * JHF_LEVERAGE_GROUP
 * JHF_DL_POSITION_RATE_CONFIG
 * JHF_NEWS
 * 
 * 
 * @author zhangyl
 *
 */
public class ConfigCache {


	private Log m_log = LogUtil.getLog(ConfigCache.class);

	private static ConfigCache configCache = new ConfigCache();

	private ConfigCache() {
	}

	public static ConfigCache getInstance() {
		return configCache;
	}

	static {
		ClearcacheListener clearcacheListener = new ClearcacheListener();
		clearcacheListener.setDaemon(true);
		clearcacheListener.start();
	}
	
	 
	
	@SuppressWarnings("unchecked")
	public List<JhfCurrency> getAllJhfCurrency() throws Exception {

		try {
		
			SimpleTreeCache simpleTreeCache = SimpleTreeCache.getInstance();
			Object obj = simpleTreeCache.get(CacheKeyConstant.CACHE_KEY_CURRENCUY_ALL);
			if (obj == null) {
				ConfigService service = new ConfigService();
				obj = service.getAllJhfCurrency();
				simpleTreeCache.put(CacheKeyConstant.CACHE_KEY_CURRENCUY_ALL, obj);
			} 
			return (List<JhfCurrency>)obj;

		} catch (Exception e) {
			m_log.error("getAllJhfCurrency failed", e);
			throw new Exception(e);
		}
	}
	

	@SuppressWarnings("unchecked")
	public List<JhfLevel> getAllLevel() throws Exception {

		try {

			SimpleTreeCache simpleTreeCache = SimpleTreeCache.getInstance();
			Object obj = simpleTreeCache.get(CacheKeyConstant.CACHE_KEY_LEVEL_ALL);
			if (obj == null) {
				ConfigService service = new ConfigService();
				obj = service.getAllLevel();
				simpleTreeCache.put(CacheKeyConstant.CACHE_KEY_LEVEL_ALL, obj);
			}
			return (List<JhfLevel>) obj;

		} catch (Exception e) {
			m_log.error("getAllLevel failed", e);
			throw new Exception(e);
		}
	}
	
	

	public JhfApplicationDate getApplicationDate(String dateKey) throws Exception {

		try {

			SimpleTreeCache simpleTreeCache = SimpleTreeCache.getInstance();
			Object obj = simpleTreeCache.get(CacheKeyConstant.CACHE_KEY_APPLICATION_DATE_BY_KEY);
			if (obj == null) {
				ConfigService service = new ConfigService();
				obj = service.getApplicationDate(dateKey);
				simpleTreeCache.put(CacheKeyConstant.CACHE_KEY_APPLICATION_DATE_BY_KEY, obj);
			}
			return (JhfApplicationDate) obj;
		} catch (Exception e) {
			m_log.error("getApplicationDate failed", e);
			throw new Exception(e);
		}
	}

	public Object get(Class clazz, Serializable id) throws Exception {
		 return this.get(clazz, id,null, DbSessionFactory.MAIN);
	 }
	
	
	 public Object get(Class clazz, Serializable id, LockMode lockMode, int dbSession) throws Exception {
		Object obj = null;
		try {
			String key =CacheKeyConstant.CACHE_KEY_ALL+clazz.getName() + SimpleTreeCache.TOKEN + id;
			
			SimpleTreeCache simpleTreeCache = SimpleTreeCache.getInstance();
			obj = simpleTreeCache.get(key);
			if (obj == null) {
				ConfigService service = new ConfigService();
				obj = service.get(clazz, id, lockMode, dbSession);
				if (obj == null || !isActive(obj)) {
					return null;
				}
				simpleTreeCache.put(key, obj);
			}

		} catch (Exception e) {
			m_log.error("get failed for " + clazz.getName(), e);
			throw new Exception("get failed", e);
		}
		return obj;
	}
	 
	 

	protected boolean isActive(Object obj) throws Exception {
		boolean isActive = false;
		Method getActiveFlag;
		getActiveFlag = obj.getClass().getMethod("getActiveFlag", null);
		BigDecimal flag = (BigDecimal) getActiveFlag.invoke(obj, null);
		if (new BigDecimal(BoolEnum.BOOL_YES_ENUM.getValue()).equals(flag)) {
			isActive = true;
		}
		return isActive;
	}
	
	

}
