package cn.bestwiz.jhf.core.configcache;

import org.apache.commons.logging.Log;

import cn.bestwiz.jhf.core.jms.DestinationConstant;
import cn.bestwiz.jhf.core.jms.SimpleSender;
import cn.bestwiz.jhf.core.util.LogUtil;



public class ClearCache {
	
	
	private static Log m_log = LogUtil.getLog(ClearCache.class);
	
	public static void main( String [] args ) {
		
		String[] clearKeys  = new String[]{"cn.bestwiz.jhf.core.dao.bean.main.JhfCurrency"} ;
		clearCache(clearKeys);
	}
	
	public static void clearCache(String[]  clearKeys){

		if(clearKeys==null || clearKeys.length==0){
			// s 为空 清空所有
			try {
				clearALLCache();
				System.out.println("clear dao cache SUCCEED for all classes !");
			}catch( Exception ex ){
				System.out.println("clear dao cache FAILED for all classes !");
			}
		}else{
			// 清空所有设置的

			for (String key : clearKeys) {
				try {
					clearCache(Class.forName(key));
					System.out.println("clear dao cache SUCCEED for class["+key+"]");
				}catch( ClassNotFoundException e ){
					System.out.println("class["+key+"] is not found");
					e.printStackTrace();
				}catch( Exception e ){
					System.out.println("clear dao cache FAILED for class["+key+"]");
					e.printStackTrace();
				}
			}
		}
	}
	
	
	public static final void clearCache(Class clszz) throws Exception{
    	try {
			SimpleSender sender = SimpleSender.getInstance(DestinationConstant.ClearDaoCacheTopic);
			
			sender.sendMessage(CacheKeyConstant.CACHE_KEY_ALL+clszz.getName());

		} catch (Exception e) {
			m_log.error("clearCache failed: "+e,e);
			throw e;
		}

    }
	
	public static final void clearALLCache() throws Exception{
    	try {
			SimpleSender sender = SimpleSender.getInstance(DestinationConstant.ClearDaoCacheTopic);
			sender.sendMessage("ALL");
		} catch (Exception e) {
			m_log.error("clearALLCache failed: "+e,e);
			throw e;
		}

    }
}
