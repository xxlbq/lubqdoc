package ratesapi.fx.sample;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

import ratesapi.fx.FxApi;
import ratesapi.fx.FxApiException;
import ratesapi.fx.FxApiListener;

/**
 * A sample program for using the FX API. 
 */
public class FxApiSample {
    
    private static final String DEFAULT_CONFIG_FILE = "FxApiSample.properties";
    
    private FxApi api = FxApi.getInstance();
    private FxApiListener listener;
    private Trader trader;
    private Properties properties;

    private boolean connected = false;
    private String spotSubscriptionId = "";
    private String customSubscriptionId = "";
    private String outrightSubscriptionId = "";
    private String swapSubscriptionId = "";

    /**
     * Entry point.  Run using: run_sample.bat [config_file]
     */
    public static void main(String[] args) {
        String filename = DEFAULT_CONFIG_FILE;
        if (args.length > 0) {
            filename = args[0];
        }
        
        FxApiSample sample;
        try {
            sample = new FxApiSample(filename);
            sample.run();
        } catch (IOException e) {
            System.err.println("Error reading config: " + e.getMessage());
        }
    }

    /**
     * Create a sample
     */
    public FxApiSample(String filename) throws IOException {
        properties = new Properties();
        properties.load(new BufferedInputStream(new FileInputStream(filename)));
        
        Runtime.getRuntime().addShutdownHook(new Thread(new ShutdownHandler(), "Shutdown"));
    }

    /**
     * Subscribes to receive quotes
     */
    public void subscribe() {
        try {
        	spotSubscriptionId = api.subscribeSpot("EURUSD", "");
        	System.out.println("*** Subscribed spot    : " + spotSubscriptionId + " ***");
            
        	outrightSubscriptionId = api.subscribeForward("AUDUSD", "");
            System.out.println("*** Subscribed outright: " + outrightSubscriptionId + " ***");
            
            swapSubscriptionId = api.subscribeSwap("USDJPY", "");
            System.out.println("*** Subscribed swap    : " + swapSubscriptionId + " ***");
            
            customSubscriptionId = api.subscribeCustom("EURJPY", FxApi.BUY, "SPOT", "EUR", 100000000, "");
            System.out.println("*** Subscribed custom  : " + customSubscriptionId + " ***");
            
            trader.setSubscriptionIds(customSubscriptionId, spotSubscriptionId, outrightSubscriptionId, swapSubscriptionId);
            
        } catch (FxApiException e) {
            System.out.println("*** Subscribe failed ***");
            System.exit(1);
        }
    }
    /**
     * Run the sample
     */
    public void run() {
        System.out.println("*** Starting sample - press <ctrl>C to terminate. ***");
        
        for (Iterator iter = properties.entrySet().iterator(); iter.hasNext();) {
            Map.Entry entry = (Map.Entry) iter.next();
            api.setProperty((String) entry.getKey(), (String) entry.getValue());
        }

        trader = new Trader();
        listener = new FxApiSampleListener(this, trader);

        System.out.println("*** Connecting ***");
        if ( connect() == FxApi.DISCONNECTED) {
            System.out.println("*** Connect failed ***");
            System.exit(1);
        }
        connected = true;
        
        subscribe();
        trader.start();

    }

    public int connect() {
        return api.connect(listener);
    }
    /*================================================================================================================*/
    
    private class ShutdownHandler implements Runnable {
        public void run() {
            System.out.println("*** Shutting down ***");
            trader.stop();
            if (connected) {
                System.out.println("*** Disconnecting ***");
                api.disconnect();        
            }
            System.out.println("*** Completed ***");
        }        
    }
}
