package ratesapi.fx.sample;

import ratesapi.fx.FxApi;
import ratesapi.fx.FxApiListener;
import ratesapi.fx.Quotes;

/** Listener for FX API events */
class FxApiSampleListener implements FxApiListener {
    
    private static final boolean SHOW_DEBUG = false;
    private static final boolean SHOW_INFO = true;

    private final Trader trader;
    private final FxApiSample sample;

    FxApiSampleListener(FxApiSample sample, Trader trader) {
        this.sample = sample;
        this.trader = trader;
    }

    public void onConnectionChanged(int connectionStatus) {
        if (connectionStatus == FxApi.CONNECTED) {
            System.out.println("*** Connection: CONNECTED ***");
        } else if (connectionStatus == FxApi.DISCONNECTED) {
            System.out.println("*** Connection: DISCONNECTED ***");
            System.out.println("Reconnecting...");
            while (sample.connect() != FxApi.CONNECTED ) {
                try {
                    Thread.sleep(1000);
                    System.out.println("Trying to reconnect...");
                } catch (InterruptedException e) {
                    System.out.println("Interrupted exception");
                    return;
                }
            }
            sample.subscribe();
        } else if (connectionStatus == FxApi.UNAVAILABLE) {
            System.out.println("*** Connection: UNAVAILABLE ***");
        } else {
            System.out.println("*** Connection: UNKNOWN - " + connectionStatus + " ***");
        }
    }
    
    public void onQuotes(Quotes quotes) {
        trader.enqueue(quotes);
    }

    public void onSubscriptionEnded(String subscriptionId) {
        System.out.println("*** Subscription Ended: " + subscriptionId + " ***");            
    }

    public void onDebug(String message) {
        if (SHOW_DEBUG) {
            System.out.println("Debug: " + message);
        }
    }

    public void onInfo(String message) {
        if (SHOW_INFO) {
            System.out.println("Info: " + message);
        }
    }

    public void onWarning(String message) {
        System.out.println("Warning: " + message);            
    }

    public void onError(String message) {
        System.out.println("Error: " + message);
    }        
}