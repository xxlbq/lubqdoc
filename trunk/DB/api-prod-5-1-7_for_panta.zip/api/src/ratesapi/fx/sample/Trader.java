package ratesapi.fx.sample;

import java.text.DecimalFormat;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import ratesapi.fx.FxApi;
import ratesapi.fx.FxApiException;
import ratesapi.fx.Quote;
import ratesapi.fx.Quotes;
import ratesapi.fx.TradeResult;
import currenex.share.fxintegrate.xmlmsgs.generated.quote;

/**
 * A queue and servicing thread that will trade any quotes passed to it
 * on the service thread. 
 */
class Trader implements Runnable {

    private final List queue = new LinkedList();
    private Thread tradingThread;
    private String customId;
    private String spotId;
    private String outrightId;
    private String swapId;
    private String clientRefPrefix = String.valueOf(System.currentTimeMillis());
    private int nextClientRefSuffix = 0;

    Trader() {
        /* Do Nothing */
    }

    /**
     * Add a quote to be traded.
     * 
     * @param quotes the quote.
     */
    void enqueue(Quotes quotes) {
        synchronized(queue) {
            queue.add(quotes);
            queue.notify();
        }
    }

    /** Start servicing quotes */
    void start() {
        tradingThread = new Thread(this, "Trader");
        tradingThread.start();
    }

    /** Stop servicing quotes */
    void stop() {
        if (tradingThread != null) {
            tradingThread.interrupt();
        }
    }

    /** Set the subscription IDs */
    public void setSubscriptionIds(String customId, String spotId, String outrightId, String swapId) {
        this.customId = customId;
        this.spotId = spotId;
        this.outrightId = outrightId;
        this.swapId = swapId;
    }

    /** Trade quotes from the queue */
    public void run() {
        Random random = new Random();

        while (!Thread.interrupted()) {
            try {
                Quotes quotes;
                synchronized (queue) {
                    while (queue.isEmpty()) {
                        queue.wait();
                    }
                    quotes = (Quotes) queue.remove(0);
                }

                // display quotes
                double[] amounts = new double[]{1000000, 7000000, 15000000};
                double customAmount = 100000000;

                try {
                    Quote tradingQuote = null;

                    if (quotes.getSubscriptionId().equals(spotId)) {
                        int decimals = quotes.getSpotPriceDecimals();

                        try {
                            //Display SPOT BUY rungs
                            Quote[] buyQuoteArray = quotes.getPriceRungs(FxApi.BUY, "SPOT", "EUR");
                            for (int j = 0; j < buyQuoteArray.length; j++) {
                                System.out.println("#### Spot Quote BUY side, rung " + (j + 1) + ": " + buyQuoteArray[j].getNearAmount() + " " + buyQuoteArray[j].getTradingCurrency() +
                                        " on date " + buyQuoteArray[j].getNearDate() + " on rate " + buyQuoteArray[j].getNearRate() + " ####");
                                if (tradingQuote == null && random.nextFloat() < 0.1) {
                                    tradingQuote = buyQuoteArray[j];
                                }
                            }

                            //Display SELL rungs
                            Quote[] sellQuoteArray = quotes.getPriceRungs(FxApi.SELL, "SPOT", "EUR");
                            for (int j = 0; j < sellQuoteArray.length; j++) {
                                System.out.println("#### Spot Quote SELL side, rung " + (j + 1) + ": " + sellQuoteArray[j].getNearAmount() + " " + sellQuoteArray[j].getTradingCurrency() +
                                        " on date " + sellQuoteArray[j].getNearDate() + " on rate " + sellQuoteArray[j].getNearRate() + " ####");
                                if (tradingQuote == null && random.nextFloat() < 0.1) {
                                    tradingQuote = sellQuoteArray[j];
                                }
                            }
                        } catch (FxApiException e) {
                            if (!e.getMessage().equals("Ladder points are not available in mock")) {
                                throw e;
                            }
                        }

                        for (int i = 0; i < amounts.length; i++) {
                            Quote quote = quotes.getQuote(FxApi.BUY, "SPOT", "EUR", amounts[i]);
                            if (quote.isValid() && quote.isTradable()) {
                                System.out.println("*** The Spot quote: Buy "+ quote.getNearAmount() + " " + quote.getTradingCurrency() +
                                                " on date " + quote.getNearDate() + " by rate " + formatRate(quote.getNearRate(), decimals) + " ***");
                            }
                            if (tradingQuote == null && random.nextFloat() < 0.5) {
                                tradingQuote = quote;
                            }
                            quote = quotes.getQuote(FxApi.SELL, "SPOT", "EUR", amounts[i]);
                            if (quote.isValid() && quote.isTradable()) {
                                System.out.println("*** The Spot quote: Sell " + quote.getNearAmount() + " " + quote.getTradingCurrency() +
                                                " on date " + quote.getNearDate() + " by rate " + formatRate(quote.getNearRate(), decimals) + " ***");
                            }
                            if (tradingQuote == null) {
                                tradingQuote = quote;
                            }
                        }
                    } else if (quotes.getSubscriptionId().equals(outrightId)) {
                        int decimals = quotes.getOutrightPriceDecimals();
                        for (int i = 0; i < amounts.length; i++) {
                            Quote quote = quotes.getQuote(FxApi.BUY, "1M", "AUD", amounts[i]);
                            if (quote.isValid() && quote.isTradable()) {
                                System.out.println("*** The Outright quote: Buy " + quote.getNearAmount() + " " + quote.getTradingCurrency() +
                                                " on date " + quote.getNearDate() + " by rate " + formatRate(quote.getNearRate(), decimals) + " ***");
                            }
                            if (tradingQuote == null && random.nextFloat() < 0.5) {
                                tradingQuote = quote;
                            }
                            quote = quotes.getQuote(FxApi.SELL, "1M", "AUD", amounts[i]);
                            if (quote.isValid() && quote.isTradable()) {
                                System.out.println("*** The Outright quote: Sell " + quote.getNearAmount() + " " + quote.getTradingCurrency() +
                                                " on date " + quote.getNearDate() + " by rate " + formatRate(quote.getNearRate(), decimals) + " ***");
                            }
                            if (tradingQuote == null) {
                                tradingQuote = quote;
                            }
                        }
                    } else if (quotes.getSubscriptionId().equals(swapId)) {
                        int decimals = quotes.getForwardPointsDecimals();
                        for (int i = 0; i < amounts.length; i++) {
                            Quote quote = quotes.getSwapQuote(FxApi.BUY, "1M", "2M", "USD", amounts[i], amounts[i]);
                            if (quote.isValid() && quote.isTradable()) {
                                System.out.println("*** The Swap quote: Buy " + quote.getNearAmount() + " " + quote.getTradingCurrency() +
                                                " on near date " + quote.getNearDate() + " on far date " + quote.getFarDate() + " by swap points " + formatRate(quote.getSwapPoints(), decimals) + " ***");
                            }
                            if (tradingQuote == null && random.nextFloat() < 0.5) {
                                tradingQuote = quote;
                            }
                            quote = quotes.getSwapQuote(FxApi.SELL, "1M", "2M", "USD", amounts[i], amounts[i]);
                            if (quote.isValid() && quote.isTradable()) {
                                System.out.println("*** The Swap quote: Sell " + quote.getNearAmount() + " " + quote.getTradingCurrency() +
                                                " on near date " + quote.getNearDate() + " on far date " + quote.getFarDate() + " by swap points " + formatRate(quote.getSwapPoints(), decimals) + " ***");
                            }
                            if (tradingQuote == null) {
                                tradingQuote = quote;
                            }
                        }
                    } else if (quotes.getSubscriptionId().equals(customId)) {
                        int decimals = quotes.getSpotPriceDecimals();
                        Quote quote = quotes.getQuote(FxApi.BUY, "SPOT", "EUR", customAmount);
                        if (quote.isValid() && quote.isTradable()) {
                            System.out.println("*** The Custom Spot quote Buy: " + quote.getNearAmount() + " " + quote.getTradingCurrency() +
                                    " on date " + quote.getNearDate() + " by rate " + formatRate(quote.getNearRate(), decimals) + " ***");
                        }
                        if (tradingQuote == null && random.nextFloat() < 0.5) {
                            tradingQuote = quote;
                        }
                        quote = quotes.getQuote(FxApi.SELL, "SPOT", "EUR", customAmount);
                        if (quote.isValid() && quote.isTradable()) {
                            System.out.println("*** The Custom Spot quote Sell: " + quote.getNearAmount() + " " + quote.getTradingCurrency() +
                                    " on date " + quote.getNearDate() + " by rate " + formatRate(quote.getNearRate(), decimals) + " ***");
                        }
                        if (tradingQuote == null) {
                            tradingQuote = quote;
                        }
                    }

                    if (random.nextFloat() < 0.1) {
                        tradeQuote(tradingQuote);
                    }
                } catch (FxApiException e) {
                    System.out.println("Unable to retreive quote from quotes: " + quotes +
                            " because of: " + e.getMessage());
                }

            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    private void tradeQuote(Quote quote) {
        if (quote.isTradable()) {
            TradeResult tradeResult = quote.trade(nextClientRef());
            System.out.println("*** The trade: " + tradeResult + " ***");
        } else {
            System.out.println("*** The quote not tradable ***");
        }
    }

    private String nextClientRef() {
        return clientRefPrefix + String.valueOf(nextClientRefSuffix++);
    }

    private String formatRate(double rate, int decimalPlaces){
        StringBuffer format = new StringBuffer("#,##0");
        format.append(".");
        for(int i = 0; i < decimalPlaces; i++) {
            format.append('0');
        }
        DecimalFormat formatter = new DecimalFormat(format.toString());
        return formatter.format(rate);
    }
}
