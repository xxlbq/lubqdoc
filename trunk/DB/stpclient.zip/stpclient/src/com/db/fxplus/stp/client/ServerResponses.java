package com.db.fxplus.stp.client;

import java.util.Hashtable;

import com.db.fxplus.stp.STPEventHandler;

/**
 *
 * <p>Title: </p>
 * <p>Description: Class to save the last server response messages. Used in STPClient menu options</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author sarath
 * @version 1.0
 */
public class ServerResponses {
    private static Hashtable responses = new Hashtable();

    //change the resonses with response objects with timestamps etc etc
    public static void saveServerResponse(String tag , String response) {
        responses.put(tag, response);
    }

    public static String getLastStatusResponse() {
        return (String) responses.get(STPEventHandler.STATUS_RESPONSE );
    }

    public static String getLastCreditStatusResponse() {
        return (String) responses.get(STPEventHandler.CREDIT_STATUS_RESPONSE );
    }

    public static String getLastCreditDisableResponse() {
        return (String) responses.get(STPEventHandler.DISABLE_RESPONSE );
    }

    public static String getLastCreditEnableResponse() {
        return (String) responses.get(STPEventHandler.ENABLE_RESPONSE );
    }

    public static String getLastSubResponse() {
        return (String) responses.get(STPEventHandler.SUBSCRIPTION_RESPONSE );
    }

    public static String getLastRecordResponse() {
        return (String) responses.get(STPEventHandler.RECORD_RESPONSE );
    }
    public static String getLastHeartbeatResponse() {
        return (String) responses.get(STPEventHandler.HEARTBEAT_RESPONSE );
    }
}//ServerResponses