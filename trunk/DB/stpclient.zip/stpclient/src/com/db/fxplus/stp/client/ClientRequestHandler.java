package com.db.fxplus.stp.client;

import com.db.fxplus.stp.STPEventHandler;
import com.db.fxplus.stp.log.Log;
import com.db.fxplus.stp.log.STPLogFactory;

/**
 *
 * <p>Title: ClientRequestHandler</p>
 * <p>Description: Client request handler which will recieve the updates from STPSubscriber. STPSubscriber will
 * recieve events from the middleware channels and call ClientRequestHandler.newEvent and leave the process handling
 * to ClientRequestHandler class. It's upto the client how to implement various messages from server. For demo, each
 * response will be saved in ServerResponses.java class. Each time there is a new message, it will update the latest
 * values with the new msg. Use LastXXResponse option of STPClient menu to view the latest udpates from server.</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
public class ClientRequestHandler implements STPEventHandler {

	private static Log logger = null;
	//Inititalize the log factory
	private static STPLogFactory logf = new STPLogFactory();

	private long id = 0;
	private String tag = null;
	private byte[] data = null;
	private String clientName = null;
	private String channelName = null;
	private long leasePeriod = 0;
	private boolean leasePeriodCheck = false;
    private int heartBeatPeriod;

	/**
	 * Constructor
	 */
	public ClientRequestHandler() {
		if(logger == null) {
			//simple logger to write with classname and timestamp onto the console. The log factory will be extended
			//with log4j functionality where the output can be routed to files or any other ouput device
			logger = logf.create(getClass().getName());
		}
	}
	/**
	 * constructor
	 * @param id - id of the message on the channale
	 * @param tag - tagname with(STATUS_REQUEST value etc etc)
	 * @param data - message data in bytes
	 * @param clientName - clientname useful to publishing. just get the channelfrom pubfactory using clientname
	 * @param channelName - channel name on which the message arrived
	 * @param leasePeriodCheck - time for which the server publish status updates and the client has to make another subscription request
	 * for getting status updates
	 * @param heartBeatPeriod check - not required for client. but can be used to send a new subscription req impl
	 */
	public ClientRequestHandler(long id, String tag, byte[] data, String clientName, String channelName, long leasePeriod, boolean leasePeriodCheck,int heartBeatPeriod) {
		this();
		this.id = id;
		this.tag = tag;
		this.data = data;
		this.clientName = clientName;
		this.channelName = channelName;
		this.leasePeriod = leasePeriod;
		this.leasePeriodCheck = leasePeriodCheck;
        this.heartBeatPeriod = heartBeatPeriod;
	}

	/**
	 * called from stpsubscriber. check the subscription lease period for sending udpates.
	 * It will save the response message from channel into a cache. At a particular time, you will get only the
	 * latest response of a particular type. The implementor should process the incomming messages according to their
	 * funcationality. The ideal implementation is save the events in the queue and process when requried. Also save it with
	 * a timestamp.
	 */
	public void newEvent(long id, String tag, byte[] data, String clientName, String channelName, long leasePeriod, boolean leasePeriodCheck,int heartBeatPeriod) {
		//set the instance var's
		setId(id);
		setTag(tag);
		setData(data);
		setClientName(clientName);
		setChannelName(channelName);
		setLeasePeriod(leasePeriod);
		setLeasePeriodCheck(leasePeriodCheck);
		//response handler to be implemented by client

		try {
			String strData = new String(data);
			if(tag.equals(HEARTBEAT_RESPONSE)) {
				ServerResponses.saveServerResponse(HEARTBEAT_RESPONSE, strData );
			} else if(tag.equals(SUBSCRIPTION_RESPONSE)) {
				ServerResponses.saveServerResponse(SUBSCRIPTION_RESPONSE,strData );
			//status request
			} else if(tag.equals(STATUS_RESPONSE)) {
				ServerResponses.saveServerResponse(STATUS_RESPONSE, strData );
			//disable response
			} else if(tag.equals(DISABLE_RESPONSE)) {
				ServerResponses.saveServerResponse(DISABLE_RESPONSE, strData );
			//enable response
			} else if(tag.equals(ENABLE_RESPONSE)) {
				ServerResponses.saveServerResponse(ENABLE_RESPONSE, strData );
			//credit status response
			} else if(tag.equals(CREDIT_STATUS_RESPONSE)) {
				ServerResponses.saveServerResponse(CREDIT_STATUS_RESPONSE, strData );
			//record request
			} else if(tag.equals(RECORD_RESPONSE)) {
				ServerResponses.saveServerResponse(RECORD_RESPONSE, strData );
			} else {
				logger.debug("*****************************************************");
				logger.debug("Unknown response recieved " + strData);
				logger.debug("*****************************************************");
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	public void setId(long id) {
		this.id = id;
	}

	public void setTag(String tag) {
		this.tag = tag;
	}

	public void setData(byte[] data) {
		this.data = data;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}

	public void setLeasePeriod(long leasePeriod) {
		this.leasePeriod = leasePeriod;
	}

	public void setLeasePeriodCheck(boolean leasePeriodCheck) {
		this.leasePeriodCheck = leasePeriodCheck;
	}
}