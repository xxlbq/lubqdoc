package com.db.fxplus.stp.client;

//Try to use qualified names
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLStreamHandler;
import java.net.URLStreamHandlerFactory;
import java.security.Security;

import com.db.fxplus.stp.HMACHandler;
import com.db.fxplus.stp.RequestSender;
import com.db.fxplus.stp.STPEventHandler;
import com.db.fxplus.stp.comms.STPChannelFactory;
import com.db.fxplus.stp.comms.STPPublisher;
import com.db.fxplus.stp.comms.STPPublisherFactory;
import com.db.fxplus.stp.comms.STPSubscriberFactory;
import com.db.fxplus.stp.config.Config;
import com.db.fxplus.stp.config.ConfigException;
import com.db.fxplus.stp.config.DefaultConfigFactory;
import com.db.fxplus.stp.domparser.DOMXMLMessageHandler;
import com.db.fxplus.stp.log.Log;
import com.db.fxplus.stp.log.LogFactory;
import com.db.fxplus.stp.log.STPLogFactory;

/**
 *
 * <p>Title: STPClient.java</p>
 * <p>Description: Test client progaram to publish stp requests and recieve responses from stpsever. The menu
 * displays various options and it will send stp requests and check the responses using the menu(LastXXResponse).
 * It implemented runnable so the menu will run continiously until exit option is selected. It is assumed that
 * the client sends the subscription request before sending any status/record requests. If a status request is sent
 * without a subscription response recieved,the server doesn't process other reqeusts. If there are no responses comming
 * fromt the server, check the heartbeat status by looking at the timestamp and check the connectivity status
 * to middleware. Check Latest XX Response options to check the udpates from the server. For more debugging, ucomment
 * the ClientRequesthandler.newEvent method debug statements. Server sends updates to the client only for a lease period
 * duratin. Once the lease period is over, client has to subscribe again for updates.</p>
 *
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author sarath
 * @version 1.0
 */
public class StpClient implements Runnable {

	private static StpClient INSTANCE;
	private static boolean isUnitTesting = false;

	private static Log logger = null;
	private static Config config = null;

	//Make it configurable
	public static final String SUB_CHANNEL_SELECTOR = "TAG_KEY <> 'b' AND TAG_KEY <> 'c' AND TAG_KEY <> 'd' AND TAG_KEY <> 'e' AND TAG_KEY <> 'f' AND TAG_KEY <> 'g'";

	//middleware address. specify the certificate(.jks) and the password in the startup script
	private static String realmURL = "";
	private static String clientRH;
	//For debug purpose
	private static String clientChannelName;

	//channel factory
	private static STPChannelFactory chf;
	private static String subChannel;
	private static String pubChannel;

	//sub factory
	private static STPSubscriberFactory sf;
	//pub factory
	private static STPPublisherFactory  pf;
	private static String serverMsgsDtdLocation;

	//publisher
	private STPPublisher[] pub = null;


	private BufferedReader m_in;
	//make it config param
	private boolean m_bWindows = true;

	//class to format messages
	private DOMXMLMessageHandler parser = null;

	private String hmacUserId;
    private LogFactory logf;

	/**
	 * Startup method
	 * @param a
	 * @throws Exception
	 */
	public static void main(String a[]) throws Exception {
		try {
			//security provider for secure connectivity
			Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());
			System.out.println("Added security provider successfully");
		} catch(Exception exp) {
			exp.printStackTrace();
			System.out.println("Error while adding security provider " + exp);
			System.exit(1);
		}
		new StpClient(a);
	}

	/**
	 * Constructor
	 * @param args
	 * @throws Exception
	 */
	public StpClient(String args[]) throws Exception {
		//load the stp config - for loading properties file
		DefaultConfigFactory fac = new DefaultConfigFactory();
		if(args[0] == null) {
			config = fac.load("stp.client.internet.cfg");
		} else {
			//file name should be complete(stp.properties)
			config = fac.load(args[0]);
		}

		//Inititalize the log factory - Simple writes to console and can be extended using log4j
		logf = new STPLogFactory();
		logger = logf.create(this);

		// Configure the system.
		setPropertiesFromFile();

		System.out.println("Creating the xdomxml msg handler for parsing xml from channel and displaying in a readable format");
		//Initialize the parser
		parser = new DOMXMLMessageHandler(getServerMsgsDtdLocation());


		//set the client request handler class. it should be mentioned in the client config
		//stp.client.requesthandler.class=com.db.fxplus.coreserver.stp.client.ClientRequestHandler
		RequestSender.setClientClass(clientRH);

		//JWS doesn't consider the the protocol handler from the system property.
		//Setting the protocol handler manually
		// Note: the URLStreamHandlerFactory can only be set ONCE per Java VM.
		// This means that the StpClient should be implemented as a Singleton.
		URL.setURLStreamHandlerFactory( new URLStreamHandlerFactory() {
			public URLStreamHandler createURLStreamHandler(final String protocol) {
				if(protocol != null && protocol.compareTo("https") == 0) {
					return new com.sun.net.ssl.internal.www.protocol.https.Handler();
				}
				return null;
			}
		});

		//Start connecting to middleware and subscribe and create channels for publish using respective factory
		//classes
		createSTPPubSub();

		//start menu thread if running StpClient from Command Prompt
		//If Unit testing, DO NOT start menu thread.
		if (!StpClient.isUnitTesting) {
			new Thread(this).start();
		}
	}

	/**
	 * menu thread run
	 */
	public void run()
	{
		try{
			boolean bExit = false;
			showMenu();
			int cmd = 0;
			m_in = new BufferedReader(new InputStreamReader(System.in));
			while (!bExit){
				System.out.flush();
				System.out.print("\t\t\t\t\t\tSelect Your Option -->");
				String strCmd = readLine().toLowerCase();
				if (strCmd.length()==0) continue;
				switch (strCmd.charAt(0)){
					// Info
					case 'a':
						showConnStatus();
						break;
					// Help
					case 'b':
						showSubReqMenu();
						break;
					case 'c':
						showStatusReqMenu();
						break;
					case 'd':
						showCreditStatusReqMenu();
						break;
					case 'e':
						showDisableReqMenu();
						break;
					case 'f':
						showEnableReqMenu();
						break;
					case 'g':
						showRecordReqMenu();
						break;
					case 'h':
						showLastSubResponse();
						break;
					case 'i':
						showLastStatusResponse();
						break;
					case 'j':
						showLastCreditStatusResponse();
						break;
					case 'k':
						showLastDisableResponse();
						break;
					case 'l':
						showLastEnableResponse();
						break;
					case 'm':
						showLastRecordResponse();
						break;
					case 'n':
						showLastHBResponse();
						break;
					case '9':
						showMenu();
						break;
					case '0' :
						bExit = true;
						System.exit(0);
						break;
				} // switch
			} // while
		} catch (Exception e){
			e.printStackTrace();
		}
	} // run

	/**
	 * Displays the connection status to middleware
	 * @throws Exception
	 */
	private void showConnStatus() throws Exception {
		System.out.println("----------------------------------------------------------------");
		System.out.println("\t\t\t\tConnection Status: " + (chf.isRegistered() ? "Connected" : "Disconnected"));
		System.out.println("----------------------------------------------------------------");
	}

	/**
	 * Displays subscription request option
	 * @throws Exception
	 */
	private void showSubReqMenu() throws Exception {
		String stpID = "";
		System.out.println("----------------------------------------------------------------");
		System.out.println("------------------------Subscription Request---------------------");
		System.out.println("-----------------------------------------------------------------");
		System.out.print("              Enter STPID:" );
		stpID=readLine().toLowerCase();
		System.out.println("-----------------------------------------------------------------");
		String stReq2 = "<?xml version=\"1.0\"?><!DOCTYPE subscriptionRQ SYSTEM \"clientMsgs.dtd\"><subscriptionRQ><stpID>" + stpID + "</stpID></subscriptionRQ>";
		publishRequest(STPEventHandler.SUBSCRIPTION_REQUEST,stReq2);
	}


    private void publishRequest(String request,String message) throws Exception {
        for(int i=0;i<pub.length;i++) {
            pub[i].write(request,message.getBytes());
        }
    }

	/**
	 * Displays the last subscription response from the server.  It also formats the message  in a readable format.
	 * @throws Exception
	 */
	private void showLastSubResponse() throws Exception {
		String stpID = "";
		System.out.println("----------------------------------------------------------------");
		System.out.println("---------------------Latest Subscription Response----------------");
		System.out.println("-----------------------------------------------------------------");
		if(serverSubscriptionResponse() != null) {
			System.out.println(serverSubscriptionResponse());
			parser.checkSubscriptionResponse(serverSubscriptionResponse());
		} else {
			System.out.println("Response not found. Check the connectivity.");
			showConnStatus();
			showLastHBResponse();
		}
		System.out.println("-----------------------------------------------------------------");
	}

	public String serverSubscriptionResponse() {
		return ServerResponses.getLastSubResponse();
	}

	/**
	 * Displays the status request menu
	 * @throws Exception
	 */
	private void showStatusReqMenu() throws Exception {
		String stpID = "";
		System.out.println("----------------------------------------------------------------");
		System.out.println("------------------------Status Request---------------------");
		System.out.println("-----------------------------------------------------------------");
		System.out.print("              Enter STPID:" );
		stpID=readLine().toLowerCase();
		System.out.println("-----------------------------------------------------------------");
		String stReq2 = "<?xml version=\"1.0\"?><!DOCTYPE statusRQ SYSTEM \"clientMsgs.dtd\"><statusRQ><stpID>" + stpID + "</stpID></statusRQ>";
		publishRequest(STPEventHandler.STATUS_REQUEST,stReq2);
	}

	/**
	 * Displays the last status response from the server.  It also formats the message  in a readable format.
	 * @throws Exception
	 */
	private void showLastStatusResponse() throws Exception {
		String stpID = "";
		System.out.println("----------------------------------------------------------------");
		System.out.println("---------------------Latest Status Response----------------");
		System.out.println("-----------------------------------------------------------------");
		if(ServerResponses.getLastStatusResponse() != null) {
			System.out.println(ServerResponses.getLastStatusResponse());
			parser.checkStatusResponse(ServerResponses.getLastStatusResponse());
		} else {
			System.out.println("Response not found. Check the connectivity.");
			showConnStatus();
			showLastHBResponse();
		}
		System.out.println("-----------------------------------------------------------------");
	}

	/**
	 * Displays the credit status request menu
	 * @throws Exception
	 */
	private void showCreditStatusReqMenu() throws Exception {
		String clientID = "";
		System.out.println("----------------------------------------------------------------");
		System.out.println("------------------------Credit Status Request---------------------");
		System.out.println("-----------------------------------------------------------------");
		System.out.print("              Enter clientID:");
		clientID = readLine().toLowerCase();
		System.out.println("-----------------------------------------------------------------");
		String creditStatusReq2 = "<?xml version=\"1.0\"?><!DOCTYPE creditStatusRQ SYSTEM \"clientMsgs.dtd\"><creditStatusRQ><clientID>"
				+ clientID
				+ "</clientID></creditStatusRQ>";
        publishRequest(STPEventHandler.CREDIT_STATUS_REQUEST, creditStatusReq2);
	}

	/**
	 * Displays the last credit status response from the server
	 * @throws Exception
	 */
	private void showLastCreditStatusResponse() throws Exception {
		String stpID = "";
		System.out.println("----------------------------------------------------------------");
		System.out.println("---------------------Latest Credit Status Response----------------");
		System.out.println("-----------------------------------------------------------------");
		if(ServerResponses.getLastCreditStatusResponse() != null) {
			System.out.println(ServerResponses.getLastCreditStatusResponse());
		} else {
			System.out.println("Response not found. Check the connectivity.");
			showConnStatus();
			showLastHBResponse();
		}
		System.out.println("-----------------------------------------------------------------");
	}

	/**
	 * Displays the disable level 3 client credit request menu
	 * @throws Exception
	 */
	private void showDisableReqMenu() throws Exception {
		String clientID = "";
		System.out.println(
			"----------------------------------------------------------------");
		System.out.println(
			"--------------------Disable Client Credit Request-----------------");
		System.out.println(
			"-----------------------------------------------------------------");
		System.out.print("              Enter clientID:");
		clientID = readLine().toLowerCase();
		System.out.println(
			"-----------------------------------------------------------------");
		String disableReq2 =
			"<?xml version=\"1.0\"?><!DOCTYPE disableRQ SYSTEM \"clientMsgs.dtd\"><disableRQ><clientID>"
				+ clientID
				+ "</clientID></disableRQ>";
		publishRequest(STPEventHandler.DISABLE_REQUEST, disableReq2);
	}

	/**
	 * Displays the last disable response from the server
	 * @throws Exception
	 */
	private void showLastDisableResponse() throws Exception {
		System.out.println(
			"----------------------------------------------------------------");
		System.out.println(
			"-----------------Latest Disable Client Credit Response------------");
		System.out.println(
			"-----------------------------------------------------------------");
		if (ServerResponses.getLastCreditDisableResponse() != null) {
			System.out.println(ServerResponses.getLastCreditDisableResponse());
		} else {
			System.out.println("Response not found. Check the connectivity.");
			showConnStatus();
			showLastHBResponse();
		}
		System.out.println(
			"-----------------------------------------------------------------");
	}

	/**
	 * Displays the enable level 3 client credit request menu
	 * @throws Exception
	 */
	private void showEnableReqMenu() throws Exception {
		String clientID = "";
		System.out.println(
			"----------------------------------------------------------------");
		System.out.println(
			"--------------------Enable Client Credit Request-----------------");
		System.out.println(
			"-----------------------------------------------------------------");
		System.out.print("              Enter clientID:");
		clientID = readLine().toLowerCase();
		System.out.println(
			"-----------------------------------------------------------------");
		String enableReq2 =
			"<?xml version=\"1.0\"?><!DOCTYPE enableRQ SYSTEM \"clientMsgs.dtd\"><enableRQ><clientID>"
				+ clientID
				+ "</clientID></enableRQ>";
		publishRequest(STPEventHandler.ENABLE_REQUEST, enableReq2);
	}

	/**
	 * Displays the last enable response from the server
	 * @throws Exception
	 */
	private void showLastEnableResponse() throws Exception {
		System.out.println("----------------------------------------------------------------");
		System.out.println("-----------------Latest Enable Client Credit Response------------");
		System.out.println("-----------------------------------------------------------------");
		if (ServerResponses.getLastCreditEnableResponse() != null) {
			System.out.println(ServerResponses.getLastCreditEnableResponse());
		} else {
			System.out.println("Response not found. Check the connectivity.");
			showConnStatus();
			showLastHBResponse();
		}
		System.out.println("-----------------------------------------------------------------");
	}

	/**
	 * Displays the last record req menu
	 * @throws Exception
	 */
	private void showRecordReqMenu() throws Exception {
		String minStpID = "";
		String maxStpID = "";

		System.out.println("----------------------------------------------------------------");
		System.out.println("------------------------Record Request---------------------");
		System.out.println("-----------------------------------------------------------------");
		System.out.print("              Enter Min STPID:" );
		minStpID=readLine().toLowerCase();
		System.out.print("              Enter Max STPID:" );
		maxStpID=readLine().toLowerCase();

		System.out.println("-----------------------------------------------------------------");
		String stReq2 = "<?xml version=\"1.0\"?><!DOCTYPE recordRQ SYSTEM \"clientMsgs.dtd\"><recordRQ><minStpID>" + minStpID + "</minStpID><maxStpID>" + maxStpID + "</maxStpID></recordRQ>";
		publishRequest(STPEventHandler.RECORD_REQUEST, stReq2);
	}

	/**
	 * Displays the last record response from the server. It also formats the message  in a readable format.
	 * @throws Exception
	 */
	private void showLastRecordResponse() throws Exception {
		String stpID = "";
		System.out.println("----------------------------------------------------------------");
		System.out.println("---------------------Latest Record Response----------------");
		System.out.println("-----------------------------------------------------------------");
		if(ServerResponses.getLastRecordResponse() != null) {
			System.out.println(ServerResponses.getLastRecordResponse());
			parser.checkRecordResponseDom(hmacUserId, ServerResponses.getLastRecordResponse());
		} else {
			System.out.println("Response not found. Check the connectivity.");
			showConnStatus();
			showLastHBResponse();
		}
		System.out.println("-----------------------------------------------------------------");
	}

	/**
	 * Displays the last heartbeat response from the server
	 * @throws Exception
	 */
	private void showLastHBResponse() throws Exception {
		String stpID = "";
		System.out.println("----------------------------------------------------------------");
		System.out.println("---------------------Latest Heartbeat Response----------------");
		System.out.println("-----------------------------------------------------------------");
		if(serverHeartbeatResponse() != null) {
			System.out.println(serverHeartbeatResponse());
		} else {
			System.out.println("Response not found. Check the connectivity or heartbeat. If connected and no heartbeat response, then server is not active.");
			showConnStatus();
		}
		System.out.println("-----------------------------------------------------------------");
	}

	public String serverHeartbeatResponse() {
		String hbResponse = ServerResponses.getLastHeartbeatResponse();
		return hbResponse;
	}

	private void showMenu() throws Exception {
		System.out.println("----------------------------------------------------------------");
		System.out.println("------------------------STP Client Menu--------------------------");
		System.out.println("-----------------------------------------------------------------");
		System.out.println("              a.  Connection Status                              ");
		System.out.println("              b.  Send Subscription Request                      ");
		System.out.println("              c.  Send Status Request                            ");
		System.out.println("              d.  Send Credit Status Request                     ");
		System.out.println("              e.  Send Disable Client Credit Request             ");
		System.out.println("              f.  Send Enable Client Credit Request              ");
		System.out.println("              g.  Send Record Request                            ");
		System.out.println("              h.  Last Subscription Response                     ");
		System.out.println("              i.  Last Status Response                           ");
		System.out.println("              j.  Last Credit Status Response                    ");
		System.out.println("              k.  Last Disable Client Credit Response            ");
		System.out.println("              l.  Last Enable Client Credit Response             ");
		System.out.println("              m.  Last Record Response                           ");
		System.out.println("              n.  Last Heartbeat Response                        ");
		System.out.println("              9.  Main Menu                                      ");
		System.out.println("              0.  Exit                                           ");
		System.out.println("-----------------------------------------------------------------");
	}

	public String readLine() throws IOException
	{
		//
		// fix for Solaris JDK1.1.5 - 1.1.7 bug where blocking IO on System.in blocks all IO.
		// includes a fix for Microsoft VM bug where System.in.available() always returns 0.
		//
		String strLine = null;
		while (strLine == null)
		{
			if (!m_bWindows)
			{
				if (m_in.ready())
				{
					strLine = m_in.readLine();
				}
				else
				{
					try	{
						Thread.sleep(100);
					} catch (InterruptedException e){}
				}
			}
			else
			{
				strLine = m_in.readLine();
			}
		}
		return strLine;
	} // readline()


	void setPropertiesFromFile() throws ConfigException {
		try {
			//get the realmaddr
			realmURL = config.getString("stp.realm.addr");
			//get the list of channels. if key is not found, terminate
			setClientChannelName(config.getString("stp.client.channel.name"));

			//hmac..
			hmacUserId = config.getString("stp.client.hmac.user.id");
			String hmacKey = config.getString("stp.client.hmac.key");
			HMACHandler.setKey(hmacUserId, hmacKey.getBytes());
			setServerMsgsDtdLocation(config.getString("stp.client.xml.dtd.location"));

			// test toggle
			String toggleUnitTests = config.getString("stp.client.unittests.toggle");
			if (toggleUnitTests.equals("true")) {
				isUnitTesting = true;
			}

			//class which handles the responses from the server
			clientRH = config.getString("stp.client.requesthandler.class");
		} catch(ConfigException ce) {
			ce.printStackTrace();
			throw ce;
		}
	}


	/**
	 * Creates the sub & pub channels with the client as the key using factory classes. IN future replace the config
	 * It is assumed that a client will have only one channel for pub and one channel for sub. sub & pub channels can be same
	 * as there is a spossibility for having diffnt channels for pub & sub, it is implemented differently
	 * entries with the database info.Middleware handles all connect/disconnects. It will reconnect automatically when
	 * connection is lost.
	 */
	public void createSTPPubSub() throws Exception {
		try {
			//..create and start subscribers & publishers. get methods will create pub & sub and if you want to
			//publish onto a channel, get the publisher from the pub factory by passing the client name.
			//Init the nirvana session using STPChannelFactory
			chf = new STPChannelFactory(realmURL,logf);
			//sub factory
			sf = new STPSubscriberFactory(chf,logf);
			//pub factory
			pf = new STPPublisherFactory(chf,logf);

			//get the sub channel. key shoule be "stp.client.channel.sub"
			subChannel         = config.getString("stp.client.channel.sub");

			//get the sub channel selector. key shoule be "stp.client.channel.sub.selector"
//            String subChannelSelector = config.getString("stp.client.channel.sub.selector");

			//get the pub channel. key shoule be "stp.client.channel.pub"
			pubChannel         = config.getString("stp.client.channel.pub");

            String [] threadPoolArgs = new String[] {
                config.getString("subscriber.threadpool.inactivettl"),
                config.getString("subscriber.threadpool.maxcount"),
                config.getString("subscriber.threadpool.maxqueuesize"),
                config.getString("subscriber.threadpool.noresourcetimeout")};

			//create the channel using channel factory
			chf.createChannel(subChannel);
			chf.createChannel(pubChannel);
			//create subscriber using subscriber factory. get will create the sub and saves with clientname as the key
			//create metod is private to avoid multiple creations
			sf.getSTPSubscriber(getClientChannelName(), subChannel, SUB_CHANNEL_SELECTOR,threadPoolArgs);

			logger.debug("The subscriber factory : " + sf);
			//create publisher in the begining only. so the req handlers/response handlers, can just do get method
			//to publish
			//while publishing user STPClient.getPubFactory().getSTPPublisber(clientChannelName);
			//create metod is private to avoid multiple creations
			pub = pf.getSTPPublisher(getClientChannelName(), pubChannel);
		} catch(Exception e) {
			//if any of the sub/pub fails, terminate the aplication
			//exit?
			e.printStackTrace();
			throw e;
		}
		//...nirvana comms code
	}


	/**
	 * Used for publishing
	 * @return
	 */
	public static STPPublisherFactory getPubFactory() {
		return pf;
	}

	/**
	 * Used for subscribing
	 * @return
	 */
	public static STPSubscriberFactory getSubFactory() {
		return sf;
	}


	private static void setServerMsgsDtdLocation(String dtdLocation) {
		serverMsgsDtdLocation = dtdLocation;
	}

	public static String getServerMsgsDtdLocation() {
		return serverMsgsDtdLocation;
	}

	private void setChf(STPChannelFactory channelFactory) {
		chf = channelFactory ;
	}

	public STPChannelFactory getChf() {
		return chf;
	}

	private static void setClientChannelName(String clientChannelName) {
		StpClient.clientChannelName = clientChannelName;
	}

	private static String getClientChannelName() {
		return clientChannelName;
	}
}
